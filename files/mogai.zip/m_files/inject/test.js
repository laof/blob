console.log("mogai.test.inject.js");
