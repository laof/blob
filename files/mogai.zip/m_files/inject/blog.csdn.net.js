var d = document.querySelector('#content_views')

if (d) {
  d.removeAttribute('id')
}
console.log('fuck csdn!')
